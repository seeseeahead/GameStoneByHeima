package com.wtbu;

import javax.swing.*;

public class StoneApp {
    public static void main(String[] args) {
        new MainStone();
    }
}
