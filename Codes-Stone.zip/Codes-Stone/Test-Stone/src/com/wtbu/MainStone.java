package com.wtbu;



import javax.swing.*;
import java.awt.event.*;
import java.util.Random;

public class MainStone extends JFrame implements KeyListener, ActionListener {
    int[][] datas = new int[4][4];
    int x0 = 3;
    int y0 = 3;
//    boolean flag = false;
    int a =0;
    //计算分数:移动次数
    int count = 0;

    public MainStone(){
        initJFrame();
        initJMenu();
        initDate();
        this.addKeyListener(this);
        setVisible(true);
    }

    /**
     * 初始化窗体
     */
    public void initJFrame(){
        setSize(514,595);//大小
        setLocationRelativeTo(null);//居中
        setAlwaysOnTop(true);//置顶
        setDefaultCloseOperation(3);//正常关闭
        setTitle("石头迷阵单机版");

        setLayout(null);//取消默认布局

        //int num = 0;

    }

    /**
     * 绘制游戏页面
     */
    public void paintJFrame(){
        getContentPane().removeAll();//每次初始化，消除之前的并重新加载

        //游戏成功
        if(a == 16){
            JLabel img_win = new JLabel(new ImageIcon("D:\\heima\\Material\\Stone-image\\win.png"));
            img_win.setBounds(124,230,266,88);
            getContentPane().add(img_win);
            this.removeKeyListener(this);
        }

        for(int i = 0;i < 4;i++){
            for (int j = 0;j < 4;j++){
                JLabel image_1 = new JLabel(new ImageIcon("D:\\heima\\Material\\Stone-image\\"+datas[i][j]+".png"));
                image_1.setBounds(50 + 100 * j,90 + 100 * i,100,100);
                getContentPane().add(image_1);
                //num++;
            }
        }

        JLabel background = new JLabel(new ImageIcon("D:\\heima\\Material\\Stone-image\\background.png"));
        background.setBounds(26,30,458,484);
        getContentPane().add(background);

        //分数
        JLabel scoreText = new JLabel("步数:"+ count);
        scoreText.setBounds(30,2,100,60);
        getContentPane().add(scoreText);


        getContentPane().repaint();//重新绘制
    }

    /**
     * 菜单栏
     */
    public void initJMenu(){
        JMenuBar jMenuBar = new JMenuBar();
        JMenu jMenu = new JMenu("功能");
        jMenuBar.add(jMenu);

        JMenuItem jMenuItem = new JMenuItem("重新开始");
        jMenu.add(jMenuItem);

        jMenuItem.addActionListener(this);

        super.setJMenuBar(jMenuBar);

    }

    /**
     * 数组初始化，打乱数字方块
     */
    public void initDate(){
        //1.创建一个一维数组，包含所有游戏方块元素
        int[] arr = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        //2.首先创建随机数
        Random r = new Random();
        //3.遍历一维数组，将随机方块与遍历方块进行交换来做到打乱的目的
        for (int i = 0; i < arr.length; i++) {
            int index = r.nextInt(arr.length);
            int temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;
        }
        //4.遍历打乱后的数组，取出每一个数组，放到二维数组中
        for (int i = 0; i < arr.length; i++) {
            datas[i/4][i%4] = arr[i];
            if(arr[i] == 0){//记录方块0的所在位置方便后续游戏操作
                x0 = i / 4;
                y0 = i % 4;
            }
        }
        //重新初始化游戏页面
        paintJFrame();
    }

    /**
     * 键盘监听事件来进行0号方块左移动
     */
    public void moveLeft(){
        int Y = y0;
        l:
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                if(i == x0 && j == y0){

                    int temp = datas[x0][y0];
                    datas[x0][y0] = datas[x0][y0-1];
                    datas[x0][y0-1] = temp;
                    y0--;
                    if(y0 != Y){
                        count++;
                    }
                    break l;
                }
            }
        }
        paintJFrame();
    }

    /**
     * 键盘监听事件来进行0方块上移动
     */
    public void moveTop(){
        int X = x0;
        l:
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                if(i == x0 && j == y0){
                    int temp = datas[x0][y0];
                    datas[x0][y0] = datas[x0-1][y0];
                    datas[x0-1][y0] = temp;
                    x0--;
                    if(y0 != X){
                        count++;
                    }
                    break l;
                }
            }
        }
        paintJFrame();
    }

    /**
     * 键盘监听事件来进行0方块上移动
     */
    public void moveRight(){
        int Y = y0;
        l:
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                if(i == x0 && j == y0){
                    int temp = datas[x0][y0];
                    datas[x0][y0] = datas[x0][y0+1];
                    datas[x0][y0+1] = temp;
                    y0++;
                    if(y0 != Y){
                        count++;
                    }
                    break l;
                }
            }
        }
        paintJFrame();
    }

    /**
     * 键盘监听事件来进行0方下移动
     */
    public void moveBottom(){
        int X = x0;
        l:
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                if(i == x0 && j == y0){
                    int temp = datas[x0][y0];
                    datas[x0][y0] = datas[x0+1][y0];
                    datas[x0+1][y0] = temp;
                    x0++;
                    if(y0 != X){
                        count++;
                    }
                    break l;
                }
            }
        }
        paintJFrame();
    }

    /**
     *判断游戏是否成功
     */
    public void Victory(){
        a = 0;
        //1.创建一个正确顺序的数组
        int[][] arr1 = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,0}};
        //2.定义一个值为0的变量,已提升为成员变量
        //3.遍历data数组，判断值是否都与正确顺序的数组对应；若全部正确则游戏成功；
        l:
        for (int i = 0; i < arr1.length; i++) {
            for (int j = 0; j < arr1[i].length; j++) {
                if(datas[i][j] ==  arr1[i][j]){
                    a++;
                }else{
                    break l;
                }
            }
        }
    }

    /**
     * 游戏作弊键
     */
    public void Cheat(){
        //1.创建新正确顺序的数组
        int[][] AnsweArr = {{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,0}};
        //2.把正确顺序的数组遍历赋值给玩家数组
        for (int i = 0; i < AnsweArr.length; i++) {
            for (int j = 0; j < AnsweArr[i].length; j++) {
                datas[i][j] = AnsweArr[i][j];
            }
        }
    }

    /**
     * 重新开始游戏
     */
    public void restart(){
        count = 0;
        initDate();
        paintJFrame();
    }

    @Override
    public void keyTyped(KeyEvent e) { }

    /**
     * 进行游戏移动操作，键盘监听事件
     * @param e
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if(code == 37){
            if(y0 == 0){
                return;
            }else{
                moveLeft();
            }
        }else if(code == 38){
            if(x0 == 0){
                return;
            }else{
                moveTop();
            }

        }else if(code == 39){
            if(y0 == datas.length-1){
                return;
            }else{
                moveRight();
            }

        }else if(code == 40){
            if(x0 == datas.length-1){
                return;
            }else{
                moveBottom();
            }
        }else if(code == 10){
            Cheat();
        }else{
            return;
        }
        Victory();
        paintJFrame();
    }

    @Override
    public void keyReleased(KeyEvent e) { }

    //重新游戏都需要点击事件
    @Override
    public void actionPerformed(ActionEvent e) {
        restart();
    }



}
